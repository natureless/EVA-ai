# EVA Brand Kit / 品牌交付包

Brand 1.0.0 · Components 1.1.3 · Token schema 1 · Package format 2

打开 preview.html 可离线查看所有静态资产，并运行真实的二阶 / 三阶动态组件。没有外部字体、网络依赖或模型调用。

## 资产

- svg/：二阶和三阶，Primary、Monochrome、Dark、Light，六种观察角；共 48 个标准 SVG。
- icons/：16、32、48px 二阶三视角微标。
- selected/eva-selected.svg：当前选择 3 × 3 / dark / front。
- PNG：selected/eva-selected.png, icons/favicon-16.png, icons/favicon-32.png, icons/favicon-48.png
- tokens.json：品牌 Token；manifest.json：版本、规范化规则／几何／Token 指纹、组件和文件 SHA-256、字节数与 CRC32。CHANGELOG.md：品牌变更记录。
- components/：原生 JavaScript 动态组件和几何样式；preview.html 同时提供接入示例。
- components/ui-system.css、ui-theme.js：与产品相同的呈现 Token 和浅色／深色／系统主题；文件全部随包交付。

## 接入

按顺序加载 components/logo-tokens.js、cube-state.js、cube-animator.js、cube-logo.js，并引用 eva-logo.css。
根节点使用 cube-stage eva-logo 类和 data-phase="5"，内部结构参照 preview.html。
创建 CubeState、CubeAnimator 和 CubeLogo 后显式调用 play({loop:true})；solve() 严格逆序撤销已提交动作。
动效失败后保留状态与日志，使用 recover({createAnimator}) 核对日志、重建呈现器并逆序复原；工厂必须沿用传入的状态对象。
日志不一致或恢复再次失败时保持错误，显示独立静态标识；不直接重置坐标或重复启动循环。重复重试共享一个任务。
正常对话采用二阶，深度思考采用三阶。响应完成、结构切换及退出演示前应等待 solve()。
遵循 prefers-reduced-motion，并在页面隐藏时 pause('hidden')，显示时 resume('hidden')。
预览主题更换只更新呈现，不重建魔方或改变动作日志。浏览器文件来源的存储能力不同，存储不可用时主题仍在当前页面生效并显示提示。
从 SVG / PNG 取得静态品牌资产，不截取打乱中的动态帧。

## 使用规范

L1 动态主标：160px 以上；L2 产品标识：48–160px；L3 微标：16–48px。
保持整体比例；四周留白至少为标识宽度的 25%。SVG / PNG 已包含留白。
允许主题变体、单色、等比缩放、静态展示和合法转动。
禁止拉伸、独立缩放模块、随意修改间隙与圆角、添加霓虹或复杂纹理。
动态演示结束必须复原。指纹用于内容与版本追踪；没有签名，不证明来源身份或官方授权。CRC32 用于检测文件损坏。
格式 1 为无来源指纹的旧包；格式 2 增加来源追踪。未知格式／Token schema 或不支持的品牌与组件主版本应拒绝，不猜测迁移。
