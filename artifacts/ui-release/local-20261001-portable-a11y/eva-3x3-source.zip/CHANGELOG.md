# EVA Brand Changelog

## Brand 1.0.0 / Components 1.1.1 — 2026-10-01

Portable preview separates visual move status from polite action announcements. Continuous turns do not repeat live-region updates; start, restoration, model changes, reduced motion and errors remain announced. Geometry and legal motion contracts are unchanged.

## Brand 1.0.0 / Components 1.1.0 — 2026-10-01

Portable preview now includes the shared product presentation tokens and light/dark/system theme controller. Theme changes preserve the cube state and journal. Two additional local presentation files are tracked by source and file fingerprints. Geometry, motion API, token schema and package format remain compatible.

## Brand 1.0.0 / Components 1.0.0 — 2026-09-30

First explicit version baseline for the existing 2×2 / 3×3 geometry, monochrome variants, legal move journal and inverse restoration. Geometry and motion contracts are unchanged.

Package format 2 adds separate brand, token schema and component versions; normalized rule fingerprints and source/file SHA-256 fingerprints. Format 1 remains a legacy package without provenance.
